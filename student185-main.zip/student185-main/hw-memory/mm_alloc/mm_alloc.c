/*
 * mm_alloc.c
 */

#include "mm_alloc.h"
#include "../pintos/src/lib/stdbool.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

static struct metadata* block_list = NULL;

struct metadata {
  size_t size; /* size of block */
  bool free;   /* whether the block is free */
  struct metadata* prev; // previous block
  struct metadata* next; // next block
  //struct list_elem elem; /* list element for all block_metadata list */
};

void* malloc_init(size_t size) {
  block_list = (struct metadata*) sbrk(BLOCK_SIZE + size);
  block_list->next = NULL;
  block_list->prev = NULL;
  block_list->free = false;
  block_list->size = size;
  //list_init(block_list);
  void* ptr = (void*)((char*)block_list+ BLOCK_SIZE);
  memset(ptr, 0, block_list->size);
  return ptr;
}


// Function to split a large block into two smaller blocks
void split_block(struct metadata* b, size_t size) {
  struct metadata* new_block = (struct metadata *)((char *)b + size + BLOCK_SIZE);
  //struct metadata* b = list_entry(a, struct metadata, elem);
  //struct metadata* m = list_entry(new_block, struct metadata, elem);
  new_block->size = b->size - size - BLOCK_SIZE;
  new_block->free = true;
  new_block->next = b->next;
  new_block->prev = b;
  b->size = size;
  b->free = false;
  if (b->next != NULL) {
    b->next->prev = new_block;
  }
  b->next = new_block;
}

void* mm_malloc(size_t size) {
  if (size == 0)
    return NULL;
  
  if (block_list == NULL) {
    void* ptr = malloc_init(size);
    return ptr;
  }

  if (block_list == (void*) -1)
    return NULL;

  //struct list_elem* e;

  struct metadata* block = block_list;
  while (block != NULL) {
    if (block->free && block->size >= size) {
      if (block->size > size + BLOCK_SIZE) {
        split_block(block, size);
      } 
      /* zero-fill memory */
      block->free = false;
      void* ptr = (void*)((char*)block + BLOCK_SIZE);
      memset(ptr, 0, block->size);
      return ptr;
    }
    block = block->next;
  }

  struct metadata* new_block = (struct metadata*) sbrk(BLOCK_SIZE + size);
  if (new_block == (void*) -1)
    return NULL;

  new_block->size = size;
  new_block->free = false;
  new_block->next = NULL;
  new_block->prev = NULL;

  struct metadata* last_block = block_list;
  while (last_block->next != NULL) {
    last_block = last_block->next;
  }
  last_block->next = new_block;
  new_block->prev = last_block;

  /* zero-fill memory */
  void* ptr = (void*)((char*)new_block + BLOCK_SIZE);
  memset(ptr, 0, new_block->size);
  return ptr;
}

void* mm_realloc(void* ptr, size_t size) {
  if (size == 0) {
    if (ptr != NULL)
      mm_free(ptr);
    return NULL;
  }

  if (ptr == NULL) {
    // same as calling malloc
    return mm_malloc(size);
  }

  struct metadata* block = (struct metadata *)((char*) ptr - BLOCK_SIZE);
  size_t size_original = block->size;

  if (size <= size_original) {
    block->size = size;
    return ptr;
  } else {
    void* new_ptr = mm_malloc(size);
    if (new_ptr == NULL)
      return NULL;

    memcpy(new_ptr, ptr, size_original);
    mm_free(ptr);
    return new_ptr;
  }
}

void mm_free(void* ptr) {
  if (ptr == NULL) 
    return;

  struct metadata* free_data = (struct metadata*)((char*) ptr - BLOCK_SIZE);
  
  if (free_data && free_data->free == true) {
    return;
  } else {
    free_data->free = true;
    if (free_data->next && free_data->prev) {
      if (!free_data->next->free && !free_data->prev->free)
        return;
    }
  }

  if (free_data->next == NULL) { //if last block freed change heap size
    if (free_data->prev && free_data->prev->free) {
      if (free_data->prev->prev) {
        free_data->prev->prev->next = NULL;
      } else {
        block_list = NULL;
      }
      sbrk(-(free_data->size + free_data->prev->size + 2*BLOCK_SIZE));
      return;
    }
    if (free_data->prev) {
      free_data->prev->next = NULL;
      sbrk(-(free_data->size + BLOCK_SIZE));
      return;
    }
    if (free_data->prev == NULL) {
      sbrk(-(free_data->size + BLOCK_SIZE));
      block_list = NULL;
      return;
    }
  }

  // merge with next if free
  if (free_data->next != NULL && free_data->next->free) {
    free_data->size += (free_data->next->size + BLOCK_SIZE);
    free_data->next = free_data->next->next;
    if (free_data->next != NULL) {
      free_data->next->prev = free_data;
    }
  }

  // merge with prev if free
  free_data = free_data->prev;
  if (free_data && free_data->next->free) {
    free_data->size += (free_data->next->size + BLOCK_SIZE);
    free_data->next = free_data->next->next;
    if (free_data->next != NULL)
      free_data->next->prev = free_data;
  }
}