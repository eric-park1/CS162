/*
 * mm_alloc.h
 *
 * Exports a clone of the interface documented in "man 3 malloc".
 */

//#include "../pintos/src/lib/kernel/list.h"

#pragma once

#ifndef _malloc_H_
#define _malloc_H_
#define BLOCK_SIZE sizeof(struct metadata)

#include <stdlib.h>
//#include "../pintos/src/lib/stdbool.h"
//#include "../pintos/src/lib/kernel/list.h"

// struct metadata {
//     size_t size; /* size of block */
//     bool free;   /* whether the block is free */
//     struct metadata* prev; // previous block
//     struct metadata* next; // next block
//     //struct list_elem elem; /* list element for all block_metadata list */
// };

void* mm_malloc(size_t size);
void* mm_realloc(void* ptr, size_t size);
void mm_free(void* ptr);

#endif
