#ifndef TESTS_MEMORY_SBRK_OOM_H
#define TESTS_MEMORY_SBRK_OOM_H

void test_sbrk_oom(int num_iterations, int step_size);

#endif /* tests/memory/sbrk-oom.h */
