#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/palloc.h"
#include "userprog/process.h"

static void syscall_handler(struct intr_frame*);

void syscall_init(void) { intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall"); }

void syscall_exit(int status) {
  printf("%s: exit(%d)\n", thread_current()->name, status);
  thread_exit();
}

/*
 * This does not check that the buffer consists of only mapped pages; it merely
 * checks the buffer exists entirely below PHYS_BASE.
 */
static void validate_buffer_in_user_region(const void* buffer, size_t length) {
  uintptr_t delta = PHYS_BASE - buffer;
  if (!is_user_vaddr(buffer) || length > delta)
    syscall_exit(-1);
}

/*
 * This does not check that the string consists of only mapped pages; it merely
 * checks the string exists entirely below PHYS_BASE.
 */
static void validate_string_in_user_region(const char* string) {
  uintptr_t delta = PHYS_BASE - (const void*)string;
  if (!is_user_vaddr(string) || strnlen(string, delta) == delta)
    syscall_exit(-1);
}

static int syscall_open(const char* filename) {
  struct thread* t = thread_current();
  if (t->open_file != NULL)
    return -1;

  t->open_file = filesys_open(filename);
  if (t->open_file == NULL)
    return -1;

  return 2;
}

static int syscall_write(int fd, void* buffer, unsigned size) {
  struct thread* t = thread_current();
  if (fd == STDOUT_FILENO) {
    putbuf(buffer, size);
    return size;
  } else if (fd != 2 || t->open_file == NULL)
    return -1;

  return (int)file_write(t->open_file, buffer, size);
}

static int syscall_read(int fd, void* buffer, unsigned size) {
  struct thread* t = thread_current();
  if (fd != 2 || t->open_file == NULL)
    return -1;

  return (int)file_read(t->open_file, buffer, size);
}

static void syscall_close(int fd) {
  struct thread* t = thread_current();
  if (fd == 2 && t->open_file != NULL) {
    file_close(t->open_file);
    t->open_file = NULL;
  }
}

static bool install_page(void* upage, void* kpage, bool writable) {
  struct thread* t = thread_current();

  /* Verify that there's not already a page at that virtual
     address, then map our page there. */
  return (pagedir_get_page(t->pagedir, upage) == NULL &&
          pagedir_set_page(t->pagedir, upage, kpage, true));
}


void* syscall_sbrk(intptr_t increment) {
  struct thread* t = thread_current();
  if (!t->prev_brk) {
    t->prev_brk = t->start;
  } 

  uint8_t* previous_pg = t->prev_brk;
  void* ptr = pg_round_down(t->prev_brk - 1) + PGSIZE; // start of heap on first available page

  if (increment > 0) {
    size_t num_pages = pg_no(t->prev_brk + increment - 1) - pg_no(t->prev_brk - 1);
    void* kpage = palloc_get_multiple(PAL_USER | PAL_ZERO, num_pages);
    for (int i = 0; i < num_pages; ++i) { 
      //void* kpage = palloc_get_page(PAL_USER | PAL_ZERO);
      if (kpage != NULL) {
        if (!install_page(ptr + (PGSIZE * i), kpage + (PGSIZE * i), true)) {
          palloc_free_multiple(kpage, num_pages);
          for (int j = 0; j < i + 1; ++j) {
            pagedir_clear_page(t->pagedir, ptr + (PGSIZE * j));
          }
          return -1;
        }
      //t->prev_brk += PGSIZE;
    } else {
        palloc_free_multiple(kpage, num_pages);
        for (int j = 0; j < i + 1; ++j) {
          pagedir_clear_page(t->pagedir, ptr + (PGSIZE * j));
        }
        return -1;
      }
    }
  } else {
    size_t num_pages = pg_no(t->prev_brk - 1) - pg_no(t->prev_brk - 1 + increment);
    //size_t num_pages = (increment - 1) / PGSIZE;
    uint8_t* upage = NULL;
    for (int i = 0; i < num_pages; ++i) {
      upage = pg_round_down(t->prev_brk - 1) + (PGSIZE * -i);
      palloc_free_page(pagedir_get_page(t->pagedir, upage));
      pagedir_clear_page(t->pagedir, upage);
    }
  }
  t->prev_brk += increment;
  return previous_pg;
}

static void syscall_handler(struct intr_frame* f) {
  uint32_t* args = (uint32_t*)f->esp;
  struct thread* t = thread_current();
  t->in_syscall = true;

  validate_buffer_in_user_region(args, sizeof(uint32_t));
  switch (args[0]) {
    case SYS_EXIT:
      validate_buffer_in_user_region(&args[1], sizeof(uint32_t));
      syscall_exit((int)args[1]);
      break;

    case SYS_OPEN:
      validate_buffer_in_user_region(&args[1], sizeof(uint32_t));
      validate_string_in_user_region((char*)args[1]);
      f->eax = (uint32_t)syscall_open((char*)args[1]);
      break;

    case SYS_WRITE:
      validate_buffer_in_user_region(&args[1], 3 * sizeof(uint32_t));
      validate_buffer_in_user_region((void*)args[2], (unsigned)args[3]);
      f->eax = (uint32_t)syscall_write((int)args[1], (void*)args[2], (unsigned)args[3]);
      break;

    case SYS_READ:
      validate_buffer_in_user_region(&args[1], 3 * sizeof(uint32_t));
      validate_buffer_in_user_region((void*)args[2], (unsigned)args[3]);
      f->eax = (uint32_t)syscall_read((int)args[1], (void*)args[2], (unsigned)args[3]);
      break;

    case SYS_CLOSE:
      validate_buffer_in_user_region(&args[1], sizeof(uint32_t));
      syscall_close((int)args[1]);
      break;
    
    case SYS_SBRK:
      //validate_buffer_in_user_region(&args[1], sizeof(uint32_t));
      f->eax = syscall_sbrk(args[1]);
      break;

    default:
      printf("Unimplemented system call: %d\n", (int)args[0]);
      break;
  }

  t->in_syscall = false;
}
